//: Playground - noun: a place where people can play

// Lesson 1: Syntax

import Cocoa

var str = "Hello, the number is "

var num = 2

print(str + String(num))

/*
Lesson 2: Declaring variables
*/

var stringVariable:String
stringVariable = "variableValue"

var numberVariable:Int
numberVariable = 39

var decimalNumberVariable:Double
decimalNumberVariable = 39.93

/*
Lesson 3: String
*/

var sentence:String

var name = "Patrik"
print(name)

var doing = "is creating"
print(doing)

var what = "programming lessons!"
print(what)

sentence = name
print(sentence)

sentence += " "
sentence += doing
print(sentence)

sentence += " "
sentence += what
print(sentence)

sentence = ""
print(sentence)

sentence = name + " " + doing + " " + what
print(sentence)

/*
Lesson 4: Number
*/

var number1:Double = 9
var number2:Double = 1.24

var number3:Int = Int(number1 / number2)
print(number3)


/*
Lesson 5: If/Else statements
*/

if number1 > number2 {
    print("greater")
} else if number2 > number1 {
    print("number 2 is greater")
} else {
    print("They're equal!")
}

if number1 % 3 == 0 {
    print("Correct")
}

/*
Lesson 6: For loop
*/

print(num)

var times = 12

for i in 1...times {
    num += i
}

print(num)

/*
Lesson 7: Switch statement
*/

var toCheck = 3

switch toCheck {
case 1:
    print("It's 1")
    break
case 2:
    print("It's 2")
    break
default:
    print("Default")
    break
}